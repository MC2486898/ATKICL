# atkcli 0.1.0 · ATK 会话工具

**用途：接管本机已经打开的 ATK，持有连接和协作锁，并在软件无响应时区分「原进程还在」与「原进程已消失」。** 接管使用随 ATK 安装的官方 Connect SDK。读取平台信息、场景打开状态与可识别的场景显示名；不加载、修改、保存或关闭场景。已导出的报表和 XML 可以完全离线校验。

## 1. 在这台电脑上使用

实时接管适配 Windows x64、CPython 3.12 和本机 `ATK 4.2.0-rc.2` 的 SDK；仅作离线校验时支持 Python 3.11+。Python 包依赖 `psutil>=6,<8`。安装包不包含 ATK、许可证、场景、厂商 DLL 或任何账户凭据。

本项目已有 `.venv`、`uv` 与 `psutil`。若从 wheel 安装，在 **项目根** `D:\study\math-modeling` 用 PowerShell 执行：

```powershell
uv pip install --python .\.venv\Scripts\python.exe --offline --no-deps .\dist\atkcli-0.1.0-py3-none-any.whl
$cli = '.\.venv\Scripts\atkcli.exe'
& $cli doctor
& $cli instance status
```

其他机器请从受信任来源安装所需版本的 Python、psutil 和 ATK，再安装本地 wheel。若安装位置不同，用 `--atk-home` 或环境变量 `ATK_HOME`；端口用 `--port` 或 `ATK_PORT`，默认 `127.0.0.1:6655`。SDK 仅从指定本地安装目录加载。`doctor` 会真正导入 SDK，但不会启动 GUI 或建立 TCP 连接。命令也可用 `python -m atkcli` 调用。

## 2. 接管、排队与监控

```powershell
# 接管已有实例。握手成功后返回 JSON，记录 PID、创建时间、场景和握手时间。
& $cli instance attach --timeout 20 --out session.json

# 仅接回上次那一个进程；保持连接和锁 120 s。另一个客户端占用时最多等 15 s。
& $cli instance attach --resume session.json --wait-lock 15 --hold 120 --label '课堂演示' --log session-1.jsonl

# 有则接管，没有才启动空 GUI：仅在你已确认时段可用时运行。
& $cli instance attach --start-if-missing --timeout 60

# 无响应时只用操作系统探活，连 Connect 都不需要。可以在另一条线运行时使用。
& $cli instance watch --resume session.json --duration 300 --log watch-1.jsonl
```

- `status` 是被动快照；`ABSENT` 表示未发现实例，`PROCESS_ONLY` 表示进程存在但未看到指定端口监听，`LISTENING` 表示看到了监听。`responsive: null` 表示**尚未做协议握手**。`status` 的退出码 0 指状态查询成功，自动化脚本还需读取 `state`。
- `attach` 在拿锁后核对进程名、可执行文件路径、当前账户、PID、进程创建时间及监听端口归属，再由 SDK 查询。`mode: attached` 表示复用已有实例；`mode: started` 表示显式允许且实际启动了新 GUI。已有 ATK 时，即便端口暂时没就绪，也不会再启动一个进程。默认不启动。
- 多实例且端口归属不唯一时，请用 `--pid <PID> --port <PORT>`。`--expect-scene <显示名>` 可限制当前场景；读不到、名称有歧义或不匹配时返回 `SCENE_MISMATCH`，不切换场景。场景显示名不是文件路径或内容指纹。
- `--hold` 期间持有同一个 SDK 连接与锁；中间通过操作系统探活，结束时再次只读握手。`--log` 在启动、结束、异常及每约 30 秒写一条 JSONL；`elapsed_s` 是已等待墙钟秒数，`cpu_s` 是该进程累计 CPU 秒数。两者都不是仿真完成百分比。`--timeout` 是一次握手/就绪等待的秒数，`--wait-lock` 单独计时。
- 以约 0.4 秒为轮询间隔识别原 PID 消失或创建时间改变；即使外部 SDK 阻塞，主进程仍能探活。`DEAD` 表示观测到原进程已消失，`cause: unknown`；若读得到，也记录检测当时端口监听 PID。这不能证明是人工关闭、崩溃或抢占，不能从新 PID 推断“谁关了软件”。
- 退出或 Ctrl+C 仅断开本客户端、释放锁，包括用 `--start-if-missing` 启动的 GUI 也会保留。没有后台服务。`--resume session.json` 复用的是**原进程身份**：旧进程已退则返回 `DEAD`，绝不跟随新实例。**不持久化内存星历、不缓存计算结果，不提供 MCS 中途快照或断点恢复。**

### 锁的边界

`%TEMP%\atkcli.lock` 采用操作系统文件锁。元数据记录持锁 CLI 的 PID、时间、选定的 ATK PID/创建时间、可读场景名、说明和预计持锁秒数。默认争用立即退出；`--wait-lock` 允许有界排队。锁覆盖实例，所以同一实例不同场景也不能被本工具并发接管。正常退出和客户端异常退出都会由系统释放句柄锁。**文件可以保留；文件存在不等于被占用。** `instance status` 的 `lock.held` 会尝试核验实际锁状态。格式不明的登记文件不覆盖。

锁只协调使用**同一个临时目录和同一锁约定**的客户端。它不能禁止手工操作、旧脚本或其他账户启动软件，也不能消除它们在“检查—启动”之间的竞争。分时占用登记仍然有效；即使当前 `ABSENT`，也应先确认没有其他占用安排。

## 3. 离线处理现有文件

源码包 `examples/` 提供人工构造的地面站报表、仪器温度序列和显示参数 XML。以下以项目根的文件布局为例：

```powershell
$ex = '.\tools\atkcli\examples'
& $cli reports parse   --input "$ex\ground-station.zh.txt" --out downlink.json
& $cli reports cadence --input "$ex\instrument.csv" --step 60
& $cli xml compare --before "$ex\display.before.xml" --after "$ex\display.after.xml" --path Display/Scale --numeric
```

| 命令 | 成功所表示的事实 | 不应推断的结论 |
|---|---|---|
| `reports parse` | 已有报表的编号行成功解析；`windows` 是明细，`statistics` 单独记录报告统计项。跨日、英文月、中文月、ISO UTC 均按 UTC 处理。 | “无分析数据”不足以证明没有窗口，返回 `NO_ANALYSIS_DATA` 和退出码 31。不会计算新窗口，也不接受目标清单。 |
| `reports cadence` | 对实际时间戳逐个比较相邻差值，给出 `n`、`min_step_s`、`max_step_s`、`bad_intervals`；不补点，不重采样。 | 请求步长或平均步长不能作为实际步长的证据；样本不足两个不能通过。 |
| `xml compare` | 对**你已经另存的两份文件**按指定相对路径比较叶节点。可重复 `--path`；每条在两边都必须唯一命中、有值。`--numeric` 精确比较有限十进制值与序列形状。 | 文件相同不证明 ATK 已经重新载入，也不证明字段的物理意义、开关方向或约束已生效。 |

报告输入支持 UTF-8（含 BOM）、带 BOM 的 UTF-16、GB18030，可用 `--encoding` 显式指定。仅处理受支持的 UTC 公历文本；非 UTC 时间系统和闰秒标签不猜测。已导出文本上限 64 MiB。XML 每文件上限 8 MiB，不处理 DTD/外部实体，不执行脚本。`--out` 仅创建新的 `.json`，日志仅创建新的 `.jsonl` 或 `.log`；已有输出、输入同路径以及可疑后缀直接拒绝。`--dry-run` 只列出动作，不启动或接管程序、不写日志/锁/输出。

## 4. Python 接口

```python
from atkcli import Config, Session, SessionError

try:
    with Session(Config(timeout=20, wait_lock=5, label="课堂演示")) as session:
        print(session.last)       # 本次已完成的只读握手
        session.hold(2)           # 只监控原进程 2 秒
        print(session.refresh())  # 使用已打开的同一个 SDK 连接再查一次
except SessionError as exc:
    print(exc.code, exc.as_dict())
```

另有 `atkcli.status()`、`atkcli.watch(...)`、`atkcli.doctor()`，以及 `atkcli.reports.parse_report(text)`、`atkcli.reports.check_cadence(text, expected_s)`、`atkcli.xmlcheck.compare_xml(before, after, paths, numeric=False)`。

## 5. 退出码与范围

| 码 | 含义 |
|---:|---|
| 0 | 所请求的操作成功，或完成 dry-run |
| 2 | 参数、输入格式、路径或文件读写错误 |
| 10 | 指定期限内未就绪或未获有效应答；没有因此判定 ATK 死亡 |
| 20 | 已跟踪的原实例消失或 PID 已复用 |
| 21 | 没有找到请求接管/监控的实例 |
| 31 | 数据不足或核验未通过，详见 JSON |
| 40 | 其他客户端持锁，等待时间已用尽 |
| 41 | 实例/端口/场景归属冲突，或不能安全使用现有锁文件 |
| 42 | SDK、进程信息权限或客户端握手失败 |
| 130 | 用户中断客户端 |

此版交付的是会话管理及离线校验。附件中针对对抗卫星的抵近侦察机动、侦测几何约束配置、目标访问窗口批量计算、时刻表核对及配套星历提取未实现；T1–T5 不作为这版工具的通过项。包不提供任意 Connect 命令透传。接管只使用本机官方 SDK 的 `atkOpen`、只读查询和 `atkClose`。

复验：在项目根运行 `.\.venv\Scripts\python.exe -m pytest tools/atkcli/tests -q`。源码包附测试与合成样例；测试不会启动真实 GUI。已执行的项目和未执行的现场项目见 `VERIFICATION.md`。

ClawsGO Science Agent
